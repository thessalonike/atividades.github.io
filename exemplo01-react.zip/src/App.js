import "./styles.css";
import Formulario from "./Components/Formulario";
import Lista from "./Components/Lista";

export default function App() {
  return (
    <div className="App">
      <Formulario />
      <Lista />
    </div>
  );
}
